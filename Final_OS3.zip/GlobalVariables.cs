﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_OS
{
    class GlobalVariables
    {
        public static int buffer1_state { get; set; }
        public static int buffer2_state { get; set; }
        public static int buffer3_state { get; set; }
        public static string MyGlobalString { get; set; }
        public static int[] ordernumber = new int[100];



        public static List<char> MyArray_factory = new List<char>();
        public static List<char> MyArray_buffer1 = new List<char>();
        public static List<char> MyArray_buffer2 = new List<char>();
        public static List<char> MyArray_buffer3 = new List<char>();
        public static List<char> MyArray_buffer2_car = new List<char>();
        public static List<char> MyArray_buffer3_car = new List<char>();



    }
}
