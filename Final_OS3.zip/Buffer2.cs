﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace Final_OS
{
    public class Buffer2
    {
        public List<char> bufferArray;
        public List<char> bufferArray_car;
        private DataGridView dataGridView3;
        private DataGridView dataGridView4;
        private Buffer1 buffer1;
        private Mutex bufferMutex;
        public int bufferArrayCapacity;
        public int bufferArray_carCapacity;
        private bool isMoving;
        private bool isGetting;
        public int move_speed;
        public int get_speed;

        public Buffer2(DataGridView dataGridView3, DataGridView dataGridView4, Buffer1 buffer1)
        {
            bufferArray = new List<char>();
            bufferArray_car = new List<char>();
            this.dataGridView3 = dataGridView3;
            this.dataGridView4 = dataGridView4;
            this.buffer1 = buffer1;
            bufferMutex = new Mutex();
            bufferArrayCapacity = 100;
            bufferArray_carCapacity = 200;
            this.move_speed = 2000;
            this.get_speed = 3000;
            isMoving = false;
            isGetting = false;
        }

        public void Move()
        {
            while (true)
            {
                Thread.Sleep(this.move_speed);

                bufferMutex.WaitOne();

                if (bufferArray.Count < bufferArrayCapacity  && buffer1.bufferArray2.Count > 0)
                {
                    char data = buffer1.bufferArray2[0];
                    buffer1.bufferArray2.RemoveAt(0);
                    bufferArray.Add(data);
                    GlobalVariables.MyArray_buffer2.Add(data);
                    UpdateDataGridView(dataGridView3, bufferArray);
                }

                bufferMutex.ReleaseMutex();
            }
        }

        public void Get()
        {
            while (true)
            {
                Thread.Sleep(this.get_speed);

                bufferMutex.WaitOne();

                if (bufferArray.Count > 0 && bufferArray_car.Count < bufferArray_carCapacity)
                {
                    char data = bufferArray[0];
                    bufferArray.RemoveAt(0);

                    lock (bufferArray_car)
                    {
                        bufferArray_car.Add(data);
                        GlobalVariables.MyArray_buffer2_car.Add(data);
                        UpdateDataGridView(dataGridView4, bufferArray_car);
                        //isGetting = true;
                    }
                }

                bufferMutex.ReleaseMutex();
            }
        }
        public void LoadBufferArrayFromFile(string filePath)
        {
            List<char> data = new List<char>();

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (!string.IsNullOrEmpty(line))
                        {
                            char item = line[0];
                            data.Add(item);
                        }
                    }
                }

                // 获取 buffer2Mutex 的锁，以确保安全访问 bufferArray
                bufferMutex.WaitOne();
                bufferArray = data; UpdateDataGridView(dataGridView3, bufferArray);
                bufferMutex.ReleaseMutex();
            }
            catch (Exception ex)
            {
                MessageBox.Show("读取文件失败: " + ex.Message);
            }
        }
        public void LoadBufferArrayCarFromFile(string filePath)
        {
            List<char> data = new List<char>();

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (!string.IsNullOrEmpty(line))
                        {
                            char item = line[0];
                            data.Add(item);
                        }
                    }
                }

                // 获取 buffer2Mutex 的锁，以确保安全访问 bufferArray_car
                bufferMutex.WaitOne();
                bufferArray_car = data; UpdateDataGridView(dataGridView4, bufferArray_car);
                bufferMutex.ReleaseMutex();
            }
            catch (Exception ex)
            {
                MessageBox.Show("读取文件失败: " + ex.Message);
            }
        }

        private void UpdateDataGridView(DataGridView dataGridView, List<char> data)
        {
            if (dataGridView.InvokeRequired)
            {
                dataGridView.Invoke(new MethodInvoker(() => UpdateDataGridView(dataGridView, data)));
            }
            else
            {
                dataGridView.Rows.Clear();
                for (int i = 0; i < data.Count; i++)
                {
                    dataGridView.Rows.Add(i + 1, data[i]);
                }
            }
        }
        public List<char> GetBufferArray()
        {
            return bufferArray;
        }

        public List<char> GetBufferArrayCar()
        {
            return bufferArray_car;
        }

    }
}
