﻿using System;
using System.Collections.Generic;
//using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace Final_OS
{
    public partial class Form1 : Form
    {
        private bool isPaused = false;
        private Buffer1 buffer1;
        private Buffer2 buffer2;
        private Buffer3 buffer3;
        private Thread produceThread;
        private Thread produce_Big_Thread;
        private Thread putThread;
        private Thread moveBuffer2Thread;
        private Thread getBuffer2Thread;
        private Thread moveBuffer3Thread;
        private Thread getBuffer3Thread;
        private Thread monitorThread;
        private int threadCount;
        //private Stopwatch stopwatch = new Stopwatch();
        private DateTime startTime;
        private bool isTiming = false;

        public Form1()
        {
            InitializeComponent();

            InitializeDataGridViews();

            buffer1 = new Buffer1(dataGridView1, dataGridView2);
            buffer2 = new Buffer2(dataGridView3, dataGridView4,buffer1);
            buffer3 = new Buffer3(dataGridView5, dataGridView6,buffer1);
            monitorThread = new Thread(MonitorThread);
            monitorThread.Start();


        }

        private void InitializeDataGridViews()
        {
            dataGridView1.ColumnCount = 2;
            dataGridView1.Columns[0].Name = "序号";
            dataGridView1.Columns[1].Name = "数据";

            dataGridView2.ColumnCount = 2;
            dataGridView2.Columns[0].Name = "序号";
            dataGridView2.Columns[1].Name = "数据";

            dataGridView3.ColumnCount = 2;
            dataGridView3.Columns[0].Name = "序号";
            dataGridView3.Columns[1].Name = "数据";

            dataGridView4.ColumnCount = 2;
            dataGridView4.Columns[0].Name = "序号";
            dataGridView4.Columns[1].Name = "数据";

            dataGridView5.ColumnCount = 2;
            dataGridView5.Columns[0].Name = "序号";
            dataGridView5.Columns[1].Name = "数据";

            dataGridView6.ColumnCount = 2;
            dataGridView6.Columns[0].Name = "序号";
            dataGridView6.Columns[1].Name = "数据";
        }
        

        private void UpdateThreadCount()
        {
            lblThreadCount.Text = $"Thread Count: {threadCount}";
        }

        private void btnProduce_Click(object sender, EventArgs e)
        {
            if (!isTiming)
            {
                // 开始计时
                startTime = DateTime.Now;
                isTiming = true;
                // 其他逻辑代码...
                if (produceThread == null || !produceThread.IsAlive)
                {
                    produceThread = new Thread(buffer1.Produce);
                    produceThread.Start();
                    threadCount++;
                    UpdateThreadCount();
                }
            }
            else
            {
                // 停止计时
                DateTime endTime = DateTime.Now;
                isTiming = false;

                // 计算经过的时间
                TimeSpan elapsed = endTime - startTime;

                // 弹出窗口显示经过的时间（以毫秒为单位）
                MessageBox.Show($"经过的时间为：{elapsed.TotalMilliseconds}毫秒");

                // 其他逻辑代码...
                if (produceThread == null || !produceThread.IsAlive)
                {
                    produceThread = new Thread(buffer1.Produce);
                    produceThread.Start();
                    threadCount++;
                    UpdateThreadCount();
                }
            }
        }



       
        private void button1_Click(object sender, EventArgs e)
        {
            if (produce_Big_Thread == null || !produce_Big_Thread.IsAlive)
            {
                produce_Big_Thread = new Thread(buffer1.Produce_Big);
                produce_Big_Thread.Start();
                threadCount++;
                UpdateThreadCount();
            }
        }

        private void btnPut_Click(object sender, EventArgs e)
        {
            if (putThread == null || !putThread.IsAlive)
            {
                putThread = new Thread(buffer1.Put);
                putThread.Start();
                threadCount++;
                UpdateThreadCount();
            }
        }

        private void btnMoveBuffer2_Click(object sender, EventArgs e)
        {
            if (moveBuffer2Thread == null || !moveBuffer2Thread.IsAlive)
            {
                moveBuffer2Thread = new Thread(buffer2.Move);
                moveBuffer2Thread.Start();
                threadCount++;
                UpdateThreadCount();
            }
        }

        private void btnGetBuffer2_Click(object sender, EventArgs e)
        {
            if (getBuffer2Thread == null || !getBuffer2Thread.IsAlive)
            {
                getBuffer2Thread = new Thread(buffer2.Get);
                getBuffer2Thread.Start();
                threadCount++;
                UpdateThreadCount();
            }
        }

        private void btnMoveBuffer3_Click(object sender, EventArgs e)
        {
            if (moveBuffer3Thread == null || !moveBuffer3Thread.IsAlive)
            {
                moveBuffer3Thread = new Thread(buffer3.Move);
                moveBuffer3Thread.Start();
                threadCount++;
                UpdateThreadCount();
            }
        }

        private void btnGetBuffer3_Click(object sender, EventArgs e)
        {
            if (getBuffer3Thread == null || !getBuffer3Thread.IsAlive)
            {
                getBuffer3Thread = new Thread(buffer3.Get);
                getBuffer3Thread.Start();
                threadCount++;
                UpdateThreadCount();
            }
        }

        private void button_speed_Click(object sender, EventArgs e)
        {   
            string speed_text = textBox_value.Text;
            int speed;
            int.TryParse(speed_text, out speed);
            
            string who = textBox_who.Text;
            switch (who)
            {
                case "produce":buffer1.produce_speed = speed; MessageBox.Show("设置成功"); break;
                case "produce_big": buffer1.producebig_speed = speed; MessageBox.Show("设置成功"); break;
                case "put": buffer1.put_speed = speed; MessageBox.Show("设置成功"); break;
                case "move1": buffer2.move_speed = speed; MessageBox.Show("设置成功"); break;
                case "move2": buffer3.move_speed = speed; MessageBox.Show("设置成功"); break;
                case "get1": buffer2.get_speed = speed; MessageBox.Show("设置成功"); break;
                case "get2": buffer3.get_speed = speed; MessageBox.Show("设置成功"); break;
            }
          
        }
        private void MonitorThread()
        {
            while (true)
            {
                Thread.Sleep(5); // 每隔1秒检测一次线程状态

                string threadStatus = "";

                if (produceThread != null)
                {
                    threadStatus += "Produce Thread: " + produceThread.ThreadState + Environment.NewLine;
                }

                if (produce_Big_Thread != null)
                {
                    threadStatus += "Produce Big Thread: " + produce_Big_Thread.ThreadState + Environment.NewLine;
                }

                if (putThread != null)
                {
                    threadStatus += "Put Thread: " + putThread.ThreadState + Environment.NewLine;
                }

                if (moveBuffer2Thread != null)
                {
                    threadStatus += "Move Buffer2 Thread: " + moveBuffer2Thread.ThreadState + Environment.NewLine;
                }

                if (getBuffer2Thread != null)
                {
                    threadStatus += "Get Buffer2 Thread: " + getBuffer2Thread.ThreadState + Environment.NewLine;
                }

                if (moveBuffer3Thread != null)
                {
                    threadStatus += "Move Buffer3 Thread: " + moveBuffer3Thread.ThreadState + Environment.NewLine;
                }

                if (getBuffer3Thread != null)
                {
                    threadStatus += "Get Buffer3 Thread: " + getBuffer3Thread.ThreadState + Environment.NewLine;
                }

                // 使用 Invoke 更新 UI 线程上的控件
                label_monitor.Invoke(new Action(() => label_monitor.Text = threadStatus));
            }
        }
        private void button_Monitor_Click(object sender, EventArgs e)
        {
            button_Monitor.Enabled = false; // 禁用按钮，防止重复点击

            Thread.Sleep(5000); // 等待2秒，确保监控线程已经启动

            button_Monitor.Enabled = true; // 启用按钮

            // monitorThread.IsAlive 属性表示监控线程是否仍在运行
            if (monitorThread != null && monitorThread.IsAlive)
            {
                button_Monitor.Text = "Stop Monitor"; // 修改按钮文本为 "Stop Monitor"
            }
            else
            {
                button_Monitor.Text = "Start Monitor"; // 修改按钮文本为 "Start Monitor"
            }

            /*
            string threadStatus = "";

            if (produceThread != null)
            {
                threadStatus += "Produce Thread: " + produceThread.ThreadState + Environment.NewLine;
            }

            if (produce_Big_Thread != null)
            {
                threadStatus += "Produce Big Thread: " + produce_Big_Thread.ThreadState + Environment.NewLine;
            }

            if (putThread != null)
            {
                threadStatus += "Put Thread: " + putThread.ThreadState + Environment.NewLine;
            }

            if (moveBuffer2Thread != null)
            {
                threadStatus += "Move Buffer2 Thread: " + moveBuffer2Thread.ThreadState + Environment.NewLine;
            }

            if (getBuffer2Thread != null)
            {
                threadStatus += "Get Buffer2 Thread: " + getBuffer2Thread.ThreadState + Environment.NewLine;
            }

            if (moveBuffer3Thread != null)
            {
                threadStatus += "Move Buffer3 Thread: " + moveBuffer3Thread.ThreadState + Environment.NewLine;
            }

            if (getBuffer3Thread != null)
            {
                threadStatus += "Get Buffer3 Thread: " + getBuffer3Thread.ThreadState + Environment.NewLine;
            }

            label_monitor.Text = threadStatus;
            */

        }


        private void button2_Click(object sender, EventArgs e)
        {
            isPaused = !isPaused; // 切换暂停状态

            if (isPaused)
            {
                // 暂停所有线程
                if (produceThread != null && produceThread.IsAlive)
                    produceThread.Suspend();

                if (produce_Big_Thread != null && produce_Big_Thread.IsAlive)
                    produce_Big_Thread.Suspend();

                if (putThread != null && putThread.IsAlive)
                    putThread.Suspend();

                if (moveBuffer2Thread != null && moveBuffer2Thread.IsAlive)
                    moveBuffer2Thread.Suspend();

                if (getBuffer2Thread != null && getBuffer2Thread.IsAlive)
                    getBuffer2Thread.Suspend();

                if (moveBuffer3Thread != null && moveBuffer3Thread.IsAlive)
                    moveBuffer3Thread.Suspend();

                if (getBuffer3Thread != null && getBuffer3Thread.IsAlive)
                    getBuffer3Thread.Suspend();
            }
            else
            {
                // 恢复所有线程
                if (produceThread != null && produceThread.ThreadState == ThreadState.Suspended)
                    produceThread.Resume();

                if (produce_Big_Thread != null && produce_Big_Thread.ThreadState == ThreadState.Suspended)
                    produce_Big_Thread.Resume();

                if (putThread != null && putThread.ThreadState == ThreadState.Suspended)
                    putThread.Resume();

                if (moveBuffer2Thread != null && moveBuffer2Thread.ThreadState == ThreadState.Suspended)
                    moveBuffer2Thread.Resume();

                if (getBuffer2Thread != null && getBuffer2Thread.ThreadState == ThreadState.Suspended)
                    getBuffer2Thread.Resume();

                if (moveBuffer3Thread != null && moveBuffer3Thread.ThreadState == ThreadState.Suspended)
                    moveBuffer3Thread.Resume();

                if (getBuffer3Thread != null && getBuffer3Thread.ThreadState == ThreadState.Suspended)
                    getBuffer3Thread.Resume();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string basePath = @"D:\final_os";

            string factoryPath = Path.Combine(basePath, "factory.txt");
            string buffer1Path = Path.Combine(basePath, "buffer1.txt");
            string buffer2Path = Path.Combine(basePath, "buffer2.txt");
            string buffer3Path = Path.Combine(basePath, "buffer3.txt");
            string buffer2CarPath = Path.Combine(basePath, "buffer2_car.txt");
            string buffer3CarPath = Path.Combine(basePath, "buffer3_car.txt");

            // 输出 MyArray_factory 到 factory.txt
            using (StreamWriter writer = new StreamWriter(factoryPath))
            {
                foreach (char item in GlobalVariables.MyArray_factory)
                {
                    writer.WriteLine(item);
                }
            }

            // 输出 MyArray_buffer1 到 buffer1.txt
            using (StreamWriter writer = new StreamWriter(buffer1Path))
            {
                foreach (char item in GlobalVariables.MyArray_buffer1)
                {
                    writer.WriteLine(item);
                }
            }

            // 输出 MyArray_buffer2 到 buffer2.txt
            using (StreamWriter writer = new StreamWriter(buffer2Path))
            {
                foreach (char item in GlobalVariables.MyArray_buffer2)
                {
                    writer.WriteLine(item);
                }
            }

            // 输出 MyArray_buffer3 到 buffer3.txt
            using (StreamWriter writer = new StreamWriter(buffer3Path))
            {
                foreach (char item in GlobalVariables.MyArray_buffer3)
                {
                    writer.WriteLine(item);
                }
            }

            // 输出 MyArray_buffer2_car 到 buffer2_car.txt
            using (StreamWriter writer = new StreamWriter(buffer2CarPath))
            {
                foreach (char item in GlobalVariables.MyArray_buffer2_car)
                {
                    writer.WriteLine(item);
                }
            }

            // 输出 MyArray_buffer3_car 到 buffer3_car.txt
            using (StreamWriter writer = new StreamWriter(buffer3CarPath))
            {
                foreach (char item in GlobalVariables.MyArray_buffer3_car)
                {
                    writer.WriteLine(item);
                }
            }

            MessageBox.Show("文件已成功生成！");
        }
        private void WriteToFile(string filePath, List<char> data)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                foreach (char item in data)
                {
                    writer.WriteLine(item);
                }
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            string directoryPath = @"D:\final_os\";

            // 生成 factory_now.txt
            string factoryNowFilePath = directoryPath + "factory_now.txt";
            List<char> bufferArray1 = buffer1.GetBufferArray1();
            WriteToFile(factoryNowFilePath, bufferArray1);

            // 生成 buffer1_now.txt
            string buffer1NowFilePath = directoryPath + "buffer1_now.txt";
            List<char> bufferArray2 = buffer1.GetBufferArray2();
            WriteToFile(buffer1NowFilePath, bufferArray2);

            // 生成 buffer2_now.txt
            string buffer2NowFilePath = directoryPath + "buffer2_now.txt";
            List<char> buffer2Array = buffer2.GetBufferArray();
            WriteToFile(buffer2NowFilePath, buffer2Array);

            // 生成 buffer2_car_now.txt
            string buffer2CarNowFilePath = directoryPath + "buffer2_car_now.txt";
            List<char> buffer2ArrayCar = buffer2.GetBufferArrayCar();
            WriteToFile(buffer2CarNowFilePath, buffer2ArrayCar);

            // 生成 buffer3_now.txt
            string buffer3NowFilePath = directoryPath + "buffer3_now.txt";
            List<char> buffer3Array = buffer3.GetBufferArray();
            WriteToFile(buffer3NowFilePath, buffer3Array);

            // 生成 buffer3_car_now.txt
            string buffer3CarNowFilePath = directoryPath + "buffer3_car_now.txt";
            List<char> buffer3ArrayCar = buffer3.GetBufferArrayCar();
            WriteToFile(buffer3CarNowFilePath, buffer3ArrayCar);

            MessageBox.Show("文件已成功生成！");
        }

        private void review_Click(object sender, EventArgs e)
        {
            string filePath = @"D:\final_os\factory_now.txt";
            buffer1.LoadBufferArray1FromFile(filePath);

            // 这里可以更新 dataGridView1 或执行其他操作
            string filePath1 = @"D:\final_os\buffer1_now.txt";
            buffer1.LoadBufferArray2FromFile(filePath1);

            string filePath2 = @"D:\final_os\buffer2_now.txt";
            buffer2.LoadBufferArrayFromFile(filePath2);

            string filePath3 = @"D:\final_os\buffer2_car_now.txt";
            buffer2.LoadBufferArrayCarFromFile(filePath3);

            string filePath4 = @"D:\final_os\buffer3_now.txt";
            buffer3.LoadBufferArrayFromFile(filePath4);

            string filePath5 = @"D:\final_os\buffer3_car_now.txt";
            buffer3.LoadBufferArrayCarFromFile(filePath5);


        }

        private void room_change_Click(object sender, EventArgs e)
        {
            string room_text = textBoxRoom.Text;
            int room;
            int.TryParse(room_text, out room);

            string who = textBox_buffer.Text;
            switch (who)
            {
                case "factory": buffer1.bufferArray1Capacity = room; MessageBox.Show("设置成功"); break;
                case "buffer1": buffer1.bufferArray2Capacity = room; MessageBox.Show("设置成功"); break;
                case "buffer2": buffer2.bufferArrayCapacity = room; MessageBox.Show("设置成功"); break;
                case "buffer2_car": buffer2.bufferArray_carCapacity = room; MessageBox.Show("设置成功"); break;
                case "buffer3": buffer2.bufferArrayCapacity = room; MessageBox.Show("设置成功"); break;
                case "buffer3_car": buffer3.bufferArray_carCapacity = room; MessageBox.Show("设置成功"); break;
               
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int average;
            average = (buffer1.bufferArray1.Count + buffer1.bufferArray2.Count + buffer2.bufferArray.Count + buffer2.bufferArray_car.Count + buffer3.bufferArray.Count + buffer3.bufferArray_car.Count)/6;
            Console.WriteLine("所有缓冲区平局数据数："+average);
        }
    }
}
