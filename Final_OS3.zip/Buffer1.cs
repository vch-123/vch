﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace Final_OS
{
    public class Buffer1
    {
        public List<char> bufferArray1 { get; private set; }
        public List<char> bufferArray2 { get; private set; }
        private Random random;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private Mutex buffer1Mutex;
        private Mutex buffer2Mutex;
        public int bufferArray1Capacity;
        public int bufferArray2Capacity;
        private Thread produceThread;
        private Thread produce_Big_Thread;
        private Thread putThread;
        public int produce_speed;
        public int producebig_speed;
        public int put_speed;
        public int factory_room;
        public int buffer1_room;

        public Buffer1(DataGridView dataGridView1, DataGridView dataGridView2)
        {
            bufferArray1 = new List<char>();
            bufferArray2 = new List<char>();
            random = new Random();
            this.dataGridView1 = dataGridView1;
            this.dataGridView2 = dataGridView2;
            buffer1Mutex = new Mutex();
            buffer2Mutex = new Mutex();
            bufferArray1Capacity = 200;
            bufferArray2Capacity = 100;
            this.produce_speed = 500;
            this.producebig_speed = 500;
            this.put_speed = 1000;
            
        }

        public void Produce()
        {
            while (true)
            {
                Thread.Sleep(this.produce_speed);
                char data = (char)random.Next('a', 'z' + 1);

                buffer1Mutex.WaitOne();

                if (bufferArray1.Count < bufferArray1Capacity)
                {
                    bufferArray1.Add(data);
                    
                    GlobalVariables.MyArray_factory.Add(data);

                    UpdateDataGridView(dataGridView1, bufferArray1);
                    //MessageBox.Show($"产生字符: {data}");
                }

                buffer1Mutex.ReleaseMutex();
            }
        }

        public void Produce_Big()
        {
            while (true)
            {
                Thread.Sleep(this.producebig_speed);
                char data = (char)random.Next('A', 'Z' + 1);

                buffer1Mutex.WaitOne();

                if (bufferArray1.Count < bufferArray1Capacity)
                {
                    bufferArray1.Add(data);
                    GlobalVariables.MyArray_factory.Add(data);
                    UpdateDataGridView(dataGridView1, bufferArray1);
                }

                buffer1Mutex.ReleaseMutex();
            }
        }

        public void Put()
        {
            while (true)
            {
                Thread.Sleep(this.put_speed);

                buffer1Mutex.WaitOne();
                buffer2Mutex.WaitOne();

                if (bufferArray1.Count > 0 && bufferArray2.Count < bufferArray2Capacity)
                {
                    char data = bufferArray1[0];
                    bufferArray1.RemoveAt(0);
                    bufferArray2.Add(data);
                    GlobalVariables.MyArray_buffer1.Add(data);
                    UpdateDataGridView(dataGridView2, bufferArray2);
                }

                buffer2Mutex.ReleaseMutex();
                buffer1Mutex.ReleaseMutex();
            }
        }

        public void LoadBufferArray1FromFile(string filePath)
        {
            List<char> data = new List<char>();

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (!string.IsNullOrEmpty(line))
                        {
                            char item = line[0];
                            data.Add(item);
                        }
                    }
                }

                // 获取 buffer1Mutex 的锁，以确保安全访问 bufferArray1
                buffer1Mutex.WaitOne();
                bufferArray1 = data; UpdateDataGridView(dataGridView1, bufferArray1);
                buffer1Mutex.ReleaseMutex();
            }
            catch (Exception ex)
            {
                MessageBox.Show("读取文件失败: " + ex.Message);
            }
        }
        public void LoadBufferArray2FromFile(string filePath)
        {
            List<char> data = new List<char>();

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (!string.IsNullOrEmpty(line))
                        {
                            char item = line[0];
                            data.Add(item);
                        }
                    }
                }

                // 获取 buffer1Mutex 的锁，以确保安全访问 bufferArray2
                buffer1Mutex.WaitOne();
                bufferArray2 = data; UpdateDataGridView(dataGridView2, bufferArray2);
                buffer1Mutex.ReleaseMutex();
            }
            catch (Exception ex)
            {
                MessageBox.Show("读取文件失败: " + ex.Message);
            }
        }


        private void UpdateDataGridView(DataGridView dataGridView, List<char> data)
        {
            if (dataGridView.InvokeRequired)
            {
                dataGridView.Invoke(new MethodInvoker(() => UpdateDataGridView(dataGridView, data)));
            }
            else
            {
                dataGridView.Rows.Clear();
                for (int i = 0; i < data.Count; i++)
                {
                    dataGridView.Rows.Add(i + 1, data[i]);
                }
            }
        }public List<char> GetBufferArray1()
    {
        return bufferArray1;
    }

    public List<char> GetBufferArray2()
    {
        return bufferArray2;
    }
    }
    

}
