﻿namespace Final_OS
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnProduce;
        private System.Windows.Forms.Button btnPut;
        private System.Windows.Forms.Button btnMoveBuffer2;
        private System.Windows.Forms.Button btnGetBuffer2;
        private System.Windows.Forms.Button btnMoveBuffer3;
        private System.Windows.Forms.Button btnGetBuffer3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.Label lblThreadCount;

        // Auto-generated code omitted for brevity

        private void InitializeComponent()
        {
            this.btnProduce = new System.Windows.Forms.Button();
            this.btnPut = new System.Windows.Forms.Button();
            this.btnMoveBuffer2 = new System.Windows.Forms.Button();
            this.btnGetBuffer2 = new System.Windows.Forms.Button();
            this.btnMoveBuffer3 = new System.Windows.Forms.Button();
            this.btnGetBuffer3 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.lblThreadCount = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox_who = new System.Windows.Forms.TextBox();
            this.textBox_value = new System.Windows.Forms.TextBox();
            this.button_speed = new System.Windows.Forms.Button();
            this.button_Monitor = new System.Windows.Forms.Button();
            this.label_monitor = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.review = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxRoom = new System.Windows.Forms.TextBox();
            this.room_change = new System.Windows.Forms.Button();
            this.textBox_buffer = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.SuspendLayout();
            // 
            // btnProduce
            // 
            this.btnProduce.Location = new System.Drawing.Point(51, 645);
            this.btnProduce.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnProduce.Name = "btnProduce";
            this.btnProduce.Size = new System.Drawing.Size(118, 53);
            this.btnProduce.TabIndex = 7;
            this.btnProduce.Text = "produce";
            this.btnProduce.UseVisualStyleBackColor = true;
            this.btnProduce.Click += new System.EventHandler(this.btnProduce_Click);
            // 
            // btnPut
            // 
            this.btnPut.Location = new System.Drawing.Point(545, 645);
            this.btnPut.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnPut.Name = "btnPut";
            this.btnPut.Size = new System.Drawing.Size(100, 53);
            this.btnPut.TabIndex = 8;
            this.btnPut.Text = "Put";
            this.btnPut.UseVisualStyleBackColor = true;
            this.btnPut.Click += new System.EventHandler(this.btnPut_Click);
            // 
            // btnMoveBuffer2
            // 
            this.btnMoveBuffer2.Location = new System.Drawing.Point(746, 129);
            this.btnMoveBuffer2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnMoveBuffer2.Name = "btnMoveBuffer2";
            this.btnMoveBuffer2.Size = new System.Drawing.Size(100, 53);
            this.btnMoveBuffer2.TabIndex = 9;
            this.btnMoveBuffer2.Text = "Move Buffer2";
            this.btnMoveBuffer2.UseVisualStyleBackColor = true;
            this.btnMoveBuffer2.Click += new System.EventHandler(this.btnMoveBuffer2_Click);
            // 
            // btnGetBuffer2
            // 
            this.btnGetBuffer2.Location = new System.Drawing.Point(1591, 332);
            this.btnGetBuffer2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnGetBuffer2.Name = "btnGetBuffer2";
            this.btnGetBuffer2.Size = new System.Drawing.Size(100, 53);
            this.btnGetBuffer2.TabIndex = 10;
            this.btnGetBuffer2.Text = "Get Buffer2";
            this.btnGetBuffer2.UseVisualStyleBackColor = true;
            this.btnGetBuffer2.Click += new System.EventHandler(this.btnGetBuffer2_Click);
            // 
            // btnMoveBuffer3
            // 
            this.btnMoveBuffer3.Location = new System.Drawing.Point(746, 645);
            this.btnMoveBuffer3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnMoveBuffer3.Name = "btnMoveBuffer3";
            this.btnMoveBuffer3.Size = new System.Drawing.Size(100, 53);
            this.btnMoveBuffer3.TabIndex = 11;
            this.btnMoveBuffer3.Text = "Move Buffer3";
            this.btnMoveBuffer3.UseVisualStyleBackColor = true;
            this.btnMoveBuffer3.Click += new System.EventHandler(this.btnMoveBuffer3_Click);
            // 
            // btnGetBuffer3
            // 
            this.btnGetBuffer3.Location = new System.Drawing.Point(1591, 424);
            this.btnGetBuffer3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnGetBuffer3.Name = "btnGetBuffer3";
            this.btnGetBuffer3.Size = new System.Drawing.Size(100, 53);
            this.btnGetBuffer3.TabIndex = 12;
            this.btnGetBuffer3.Text = "Get Buffer3";
            this.btnGetBuffer3.UseVisualStyleBackColor = true;
            this.btnGetBuffer3.Click += new System.EventHandler(this.btnGetBuffer3_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(17, 194);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(337, 436);
            this.dataGridView1.TabIndex = 0;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(425, 194);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(337, 436);
            this.dataGridView2.TabIndex = 1;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(854, 65);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.Size = new System.Drawing.Size(337, 320);
            this.dataGridView3.TabIndex = 2;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(1235, 65);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.Size = new System.Drawing.Size(337, 320);
            this.dataGridView4.TabIndex = 3;
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(854, 424);
            this.dataGridView5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 51;
            this.dataGridView5.Size = new System.Drawing.Size(337, 320);
            this.dataGridView5.TabIndex = 4;
            // 
            // dataGridView6
            // 
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(1235, 424);
            this.dataGridView6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.RowHeadersWidth = 51;
            this.dataGridView6.Size = new System.Drawing.Size(337, 320);
            this.dataGridView6.TabIndex = 5;
            // 
            // lblThreadCount
            // 
            this.lblThreadCount.AutoSize = true;
            this.lblThreadCount.Font = new System.Drawing.Font("华文中宋", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblThreadCount.Location = new System.Drawing.Point(13, 93);
            this.lblThreadCount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblThreadCount.Name = "lblThreadCount";
            this.lblThreadCount.Size = new System.Drawing.Size(164, 21);
            this.lblThreadCount.TabIndex = 6;
            this.lblThreadCount.Text = "Thread Count: 0";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(202, 645);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 53);
            this.button1.TabIndex = 13;
            this.button1.Text = "PRODUCE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 8);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(157, 68);
            this.button2.TabIndex = 14;
            this.button2.Text = "挂起/唤醒所有线程";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox_who
            // 
            this.textBox_who.Location = new System.Drawing.Point(497, 102);
            this.textBox_who.Name = "textBox_who";
            this.textBox_who.Size = new System.Drawing.Size(100, 25);
            this.textBox_who.TabIndex = 15;
            // 
            // textBox_value
            // 
            this.textBox_value.Location = new System.Drawing.Point(497, 133);
            this.textBox_value.Name = "textBox_value";
            this.textBox_value.Size = new System.Drawing.Size(100, 25);
            this.textBox_value.TabIndex = 16;
            // 
            // button_speed
            // 
            this.button_speed.Location = new System.Drawing.Point(603, 102);
            this.button_speed.Name = "button_speed";
            this.button_speed.Size = new System.Drawing.Size(96, 58);
            this.button_speed.TabIndex = 17;
            this.button_speed.Text = "速度控制";
            this.button_speed.UseVisualStyleBackColor = true;
            this.button_speed.Click += new System.EventHandler(this.button_speed_Click);
            // 
            // button_Monitor
            // 
            this.button_Monitor.Location = new System.Drawing.Point(714, 17);
            this.button_Monitor.Name = "button_Monitor";
            this.button_Monitor.Size = new System.Drawing.Size(103, 23);
            this.button_Monitor.TabIndex = 18;
            this.button_Monitor.Text = "Monitor";
            this.button_Monitor.UseVisualStyleBackColor = true;
            this.button_Monitor.Click += new System.EventHandler(this.button_Monitor_Click);
            // 
            // label_monitor
            // 
            this.label_monitor.AutoSize = true;
            this.label_monitor.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_monitor.Location = new System.Drawing.Point(186, 14);
            this.label_monitor.Name = "label_monitor";
            this.label_monitor.Size = new System.Drawing.Size(69, 20);
            this.label_monitor.TabIndex = 19;
            this.label_monitor.Text = "线程状态";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(497, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(202, 40);
            this.button4.TabIndex = 21;
            this.button4.Text = "记录缓冲区历史记录";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(497, 56);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(202, 40);
            this.button5.TabIndex = 22;
            this.button5.Text = "记录缓冲区当前状态";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // review
            // 
            this.review.Location = new System.Drawing.Point(714, 46);
            this.review.Name = "review";
            this.review.Size = new System.Drawing.Size(103, 68);
            this.review.TabIndex = 23;
            this.review.Text = "复现";
            this.review.UseVisualStyleBackColor = true;
            this.review.Click += new System.EventHandler(this.review_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 176);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 15);
            this.label1.TabIndex = 24;
            this.label1.Text = "Factory";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(439, 176);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 15);
            this.label2.TabIndex = 25;
            this.label2.Text = "Buffer1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(871, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 15);
            this.label3.TabIndex = 26;
            this.label3.Text = "Buffer2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(871, 406);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 15);
            this.label4.TabIndex = 27;
            this.label4.Text = "Buffer3";
            // 
            // textBoxRoom
            // 
            this.textBoxRoom.Location = new System.Drawing.Point(1611, 121);
            this.textBoxRoom.Name = "textBoxRoom";
            this.textBoxRoom.Size = new System.Drawing.Size(100, 25);
            this.textBoxRoom.TabIndex = 28;
            // 
            // room_change
            // 
            this.room_change.Location = new System.Drawing.Point(1611, 152);
            this.room_change.Name = "room_change";
            this.room_change.Size = new System.Drawing.Size(100, 48);
            this.room_change.TabIndex = 29;
            this.room_change.Text = "改变容量";
            this.room_change.UseVisualStyleBackColor = true;
            this.room_change.Click += new System.EventHandler(this.room_change_Click);
            // 
            // textBox_buffer
            // 
            this.textBox_buffer.Location = new System.Drawing.Point(1611, 90);
            this.textBox_buffer.Name = "textBox_buffer";
            this.textBox_buffer.Size = new System.Drawing.Size(100, 25);
            this.textBox_buffer.TabIndex = 30;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1611, 218);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 50);
            this.button3.TabIndex = 31;
            this.button3.Text = "汇总数据";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1800, 756);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox_buffer);
            this.Controls.Add(this.room_change);
            this.Controls.Add(this.textBoxRoom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.review);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label_monitor);
            this.Controls.Add(this.button_Monitor);
            this.Controls.Add(this.button_speed);
            this.Controls.Add(this.textBox_value);
            this.Controls.Add(this.textBox_who);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnGetBuffer3);
            this.Controls.Add(this.btnMoveBuffer3);
            this.Controls.Add(this.btnGetBuffer2);
            this.Controls.Add(this.btnMoveBuffer2);
            this.Controls.Add(this.btnPut);
            this.Controls.Add(this.btnProduce);
            this.Controls.Add(this.lblThreadCount);
            this.Controls.Add(this.dataGridView6);
            this.Controls.Add(this.dataGridView5);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox_who;
        private System.Windows.Forms.TextBox textBox_value;
        private System.Windows.Forms.Button button_speed;
        private System.Windows.Forms.Button button_Monitor;
        private System.Windows.Forms.Label label_monitor;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button review;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxRoom;
        private System.Windows.Forms.Button room_change;
        private System.Windows.Forms.TextBox textBox_buffer;
        private System.Windows.Forms.Button button3;
    }
}
