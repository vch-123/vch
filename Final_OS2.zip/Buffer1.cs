﻿using System.Threading;
using System.Windows.Forms;

namespace Final_OS
{
    class Buffer1
    {
        public int produce_click = 0;
        public int buffer_size;
        public string[] buffer;
        public Semaphore semaphoreProduce;
        public Semaphore semaphoreConsume;
        public Mutex mutex;
        public int in_index = 0;
        public int out_index = 0;

        public Buffer1(int size)
        {
            buffer_size = size;
            buffer = new string[size];
            semaphoreProduce = new Semaphore(0, size);
            semaphoreConsume = new Semaphore(size, size);
            mutex = new Mutex();
        }

        public void Produce()
        {
            while (true)
            {
                if (produce_click == 1)
                {
                    semaphoreProduce.WaitOne();
                    mutex.WaitOne();
                    buffer[in_index] = "Produced data " + in_index;
                    in_index = (in_index + 1) % buffer_size;
                    mutex.ReleaseMutex();
                    semaphoreConsume.Release();
                }
                Thread.Sleep(1000);
            }
        }

        public void Put(DataGridView dataGridView1, DataGridView dataGridView4)
        {
            while (true)
            {
                semaphoreConsume.WaitOne();
                mutex.WaitOne();
                string data = buffer[out_index];
                out_index = (out_index + 1) % buffer_size;
                mutex.ReleaseMutex();
                semaphoreProduce.Release();

                dataGridView1.Invoke((MethodInvoker)delegate {
                    dataGridView1.Rows.Add(out_index, data);
                });
                dataGridView4.Invoke((MethodInvoker)delegate {
                    dataGridView4.Rows.Add(out_index, data);
                });

                Thread.Sleep(1000);
            }
        }

        public void Move(DataGridView dataGridView2, DataGridView dataGridView1)
        {
            while (true)
            {
                semaphoreConsume.WaitOne();
                mutex.WaitOne();
                string data = buffer[out_index];
                out_index = (out_index + 1) % buffer_size;
                mutex.ReleaseMutex();
                semaphoreProduce.Release();

                dataGridView2.Invoke((MethodInvoker)delegate {
                    dataGridView2.Rows.Add(out_index, data);
                });
                dataGridView1.Invoke((MethodInvoker)delegate {
                    dataGridView1.Rows.RemoveAt(0);
                });

                Thread.Sleep(1000);
            }
        }

        public void Move1(DataGridView dataGridView5, DataGridView dataGridView1)
        {
            while (true)
            {
                semaphoreConsume.WaitOne();
                mutex.WaitOne();
                string data = buffer[out_index];
                out_index = (out_index + 1) % buffer_size;
                mutex.ReleaseMutex();
                semaphoreProduce.Release();

                dataGridView5.Invoke((MethodInvoker)delegate {
                    dataGridView5.Rows.Add(out_index, data);
                });
                dataGridView1.Invoke((MethodInvoker)delegate {
                    dataGridView1.Rows.RemoveAt(0);
                });

                Thread.Sleep(1000);
            }
        }
    }
}
