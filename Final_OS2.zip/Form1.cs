﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace Final_OS
{
    public partial class Form1 : Form
    {
        private Buffer1 buffer1;
        private Thread produceThread;
        private Thread putThread;
        private Thread moveThread;
        private Thread move1Thread;
        private Thread getThread;
        private int threadCount;

        public Form1()
        {
            InitializeComponent();
            buffer1 = new Buffer1(100);
            threadCount = 0;
        }

        private void btnProduce_Click(object sender, EventArgs e)
        {
            if (produceThread == null || !produceThread.IsAlive)
            {
                produceThread = new Thread(buffer1.Produce);
                produceThread.Start();
                threadCount++;
            }
        }

        private void btnPut_Click(object sender, EventArgs e)
        {
            if (putThread == null || !putThread.IsAlive)
            {
                putThread = new Thread(() => buffer1.Put(dataGridView1, dataGridView6));

                putThread.Start();
                threadCount++;
            }
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            if (moveThread == null || !moveThread.IsAlive)
            {
                moveThread = new Thread(buffer1.Move);
                moveThread.Start();
                threadCount++;
            }
        }

        private void btnMove1_Click(object sender, EventArgs e)
        {
            if (move1Thread == null || !move1Thread.IsAlive)
            {
                move1Thread = new Thread(buffer1.Move1);
                move1Thread.Start();
                threadCount++;
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            if (getThread == null || !getThread.IsAlive)
            {
                getThread = new Thread(buffer1.Get);
                getThread.Start();
                threadCount++;
            }
        }

        private void btnStartStopTimer_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled)
            {
                timer1.Stop();
                stopwatch.Stop();
                lblTimeElapsed.Text = $"{stopwatch.Elapsed.TotalSeconds} seconds.";
            }
            else
            {
                timer1.Start();
                stopwatch.Start();
            }

            UpdateThreadCount();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitGridView();
            stopwatch = new Stopwatch();
        }

        private void InitGridView()
        {
            // 初始化 DataGridView 控件
        }

        private void UpdateThreadCount()
        {
            lblThreadCount.Text = $"Thread Count: {threadCount}";
        }
    }
}
