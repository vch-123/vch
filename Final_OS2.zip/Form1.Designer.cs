﻿namespace Final_OS
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.btnProduce = new System.Windows.Forms.Button();
            this.btnPut = new System.Windows.Forms.Button();
            this.btnMove = new System.Windows.Forms.Button();
            this.btnMove1 = new System.Windows.Forms.Button();
            this.btnGet = new System.Windows.Forms.Button();
            this.btnStartStopTimer = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.timer1 = new System.Windows.Forms.Timer();
            this.lblTimeElapsed = new System.Windows.Forms.Label();
            this.lblThreadCount = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnProduce
            // 
            this.btnProduce.Location = new System.Drawing.Point(12, 12);
            this.btnProduce.Name = "btnProduce";
            this.btnProduce.Size = new System.Drawing.Size(127, 23);
            this.btnProduce.TabIndex = 0;
            this.btnProduce.Text = "Produce";
            this.btnProduce.UseVisualStyleBackColor = true;
            this.btnProduce.Click += new System.EventHandler(this.btnProduce_Click);
            // 
            // btnPut
            // 
            this.btnPut.Location = new System.Drawing.Point(12, 53);
            this.btnPut.Name = "btnPut";
            this.btnPut.Size = new System.Drawing.Size(127, 23);
            this.btnPut.TabIndex = 1;
            this.btnPut.Text = "Put";
            this.btnPut.UseVisualStyleBackColor = true;
            this.btnPut.Click += new System.EventHandler(this.btnPut_Click);
            // 
            // btnMove
            // 
            this.btnMove.Location = new System.Drawing.Point(12, 94);
            this.btnMove.Name = "btnMove";
            this.btnMove.Size = new System.Drawing.Size(127, 23);
            this.btnMove.TabIndex = 2;
            this.btnMove.Text = "Move";
            this.btnMove.UseVisualStyleBackColor = true;
            this.btnMove.Click += new System.EventHandler(this.btnMove_Click);
            // 
            // btnMove1
            // 
            this.btnMove1.Location = new System.Drawing.Point(12, 135);
            this.btnMove1.Name = "btnMove1";
            this.btnMove1.Size = new System.Drawing.Size(127, 23);
            this.btnMove1.TabIndex = 3;
            this.btnMove1.Text = "Move1";
            this.btnMove1.UseVisualStyleBackColor = true;
            this.btnMove1.Click += new System.EventHandler(this.btnMove1_Click);
            // 
            // btnGet
            // 
            this.btnGet.Location = new System.Drawing.Point(12, 176);
            this.btnGet.Name = "btnGet";
            this.btnGet.Size = new System.Drawing.Size(127, 23);
            this.btnGet.TabIndex = 4;
            this.btnGet.Text = "Get";
            this.btnGet.UseVisualStyleBackColor = true;
            this.btnGet.Click += new System.EventHandler(this.btnGet_Click);
            // 
            // btnStartStopTimer
            // 
            this.btnStartStopTimer.Location = new System.Drawing.Point(12, 217);
            this.btnStartStopTimer.Name = "btnStartStopTimer";
            this.btnStartStopTimer.Size = new System.Drawing.Size(127, 23);
            this.btnStartStopTimer.TabIndex = 5;
            this.btnStartStopTimer.Text = "Start/Stop Timer";
            this.btnStartStopTimer.UseVisualStyleBackColor = true;
            this.btnStartStopTimer.Click += new System.EventHandler(this.btnStartStopTimer_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(156, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(300, 150);
            this.dataGridView1.TabIndex = 6;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblTimeElapsed
            // 
            this.lblTimeElapsed.AutoSize = true;
            this.lblTimeElapsed.Location = new System.Drawing.Point(12, 264);
            this.lblTimeElapsed.Name = "lblTimeElapsed";
            this.lblTimeElapsed.Size = new System.Drawing.Size(0, 13);
            this.lblTimeElapsed.TabIndex = 7;
            // 
            // lblThreadCount
            // 
            this.lblThreadCount.AutoSize = true;
            this.lblThreadCount.Location = new System.Drawing.Point(12, 300);
            this.lblThreadCount.Name = "lblThreadCount";
            this.lblThreadCount.Size = new System.Drawing.Size(0, 13);
            this.lblThreadCount.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 332);
            this.Controls.Add(this.lblThreadCount);
            this.Controls.Add(this.lblTimeElapsed);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnStartStopTimer);
            this.Controls.Add(this.btnGet);
            this.Controls.Add(this.btnMove1);
            this.Controls.Add(this.btnMove);
            this.Controls.Add(this.btnPut);
            this.Controls.Add(this.btnProduce);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnProduce;
        private System.Windows.Forms.Button btnPut;
        private System.Windows.Forms.Button btnMove;
        private System.Windows.Forms.Button btnMove1;
        private System.Windows.Forms.Button btnGet;
        private System.Windows.Forms.Button btnStartStopTimer;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblTimeElapsed;
        private System.Windows.Forms.Label lblThreadCount;
    }
}
