﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_OS
{
    class GlobalVariables
    {
        public static int buffer1_state { get; set; }
        public static int buffer2_state { get; set; }
        public static int buffer3_state { get; set; }
        public static string MyGlobalString { get; set; }
        public static int[] ordernumber = new int[100];
    }
}
