﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace Final_OS
{
    class Buffer2
    {
        private char[] buffer;
        private int size;
        private int nextIn;
        private int nextOut;
        public Semaphore semaphorePut;
        public Semaphore semaphoreGet;
        public AutoResetEvent eventPut;
        public AutoResetEvent eventGet;
        private Thread getThread;

        public Buffer2(int size)
        {
            this.size = size;
            buffer = new char[size];
            nextIn = 0;
            nextOut = 0;
            semaphorePut = new Semaphore(size, size);
            semaphoreGet = new Semaphore(0, size);
            eventPut = new AutoResetEvent(false);
            eventGet = new AutoResetEvent(false);
            getThread = new Thread(Get);
            getThread.Start();
        }

        private void Get()
        {
            throw new NotImplementedException();
        }

        public void Put(char data)
        {
            semaphorePut.WaitOne();
            eventPut.WaitOne();

            buffer[nextIn] = data;
            nextIn = (nextIn + 1) % size;

            semaphoreGet.Release();
            eventGet.Set();
        }

        public void Get(DataGridView source, DataGridView destination)
        {
            while (true)
            {
                semaphoreGet.WaitOne();
                eventGet.WaitOne();

                char data = buffer[nextOut];
                nextOut = (nextOut + 1) % size;

                UpdateGridView(source, destination);

                semaphorePut.Release();
                eventPut.Set();

                Thread.Sleep(1000);
            }
        }

        public bool IsEmpty()
        {
            return nextIn == nextOut;
        }

        public bool IsFull()
        {
            return (nextIn + 1) % size == nextOut;
        }

        private void UpdateGridView(DataGridView source, DataGridView destination)
        {
            source.Invoke(new Action(() =>
            {
                source.Rows.Clear();
                for (int i = 0; i < size; i++)
                {
                    source.Rows.Add(i + 1, buffer[i]);
                }
            }));

            destination.Invoke(new Action(() =>
            {
                destination.Rows.Clear();
                for (int i = 0; i < size; i++)
                {
                    destination.Rows.Add(i + 1, buffer[i]);
                }
            }));
        }
    }
}
