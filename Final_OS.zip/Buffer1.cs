﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_OS
{
    class Buffer1
    {
        public Buffer2 buffer2 { get; }
        public Buffer3 buffer3 { get; }

        public int arrayroom;//
        public int empty;   //Buffer1剩余容量
        public int full;   //buffer1目前的数目

        public char[] data;
        public char[] factory;
        public int factory_empty;
        public int factory_full;
        public int put_click = 0;
        public int produce_click = 0;
        public int move_click = 0;

        public int[] order_number;
        public int put_number = 0;
        public int move_number = 0;

        public Random random = new Random();

        public Buffer1(int capacity)
        {
            this.buffer2 = new Buffer2(100);
            this.buffer3 = new Buffer3(100);
            this.arrayroom = capacity;
            this.data = new char[capacity];
            this.factory = new char[capacity];
            this.order_number = new int[capacity];
            this.order_number[0] = 1;
            this.factory_empty = capacity;
            this.factory_full = 0;
            this.empty = capacity;
            this.full = 0;
        }

        public void ProduceAsync(DataGridView dataGridView4)
        {
            Task.Run(() =>
            {
                while (this.factory_empty > 0 && this.produce_click == 1)
                {
                    char m = RandomLow();
                    this.factory[this.factory_full] = m;
                    dataGridView4.Invoke((MethodInvoker)delegate
                    {
                        dataGridView4.Rows.Add(this.order_number[this.factory_full], m);
                        dataGridView4.FirstDisplayedScrollingRowIndex = dataGridView4.RowCount - 1;
                    });
                    this.factory_full++;
                    this.factory_empty--;
                    if (this.factory_full < 100) { this.order_number[this.factory_full] = this.order_number[this.factory_full - 1] + 1; }

                    Thread.Sleep(1200);
                }
            });
        }

        public void Put(DataGridView dataGridView1, DataGridView dataGridView4)
        {
            Task.Run(() =>
            {
                while (true)
                {
                    if (GlobalVariables.buffer1_state == 0 && this.empty > 0)
                    {
                        GlobalVariables.buffer1_state = 1;
                        this.data[this.put_number] = this.factory[this.put_number];

                        dataGridView1.Invoke((MethodInvoker)delegate
                        {
                            dataGridView1.Rows.Add(this.order_number[this.put_number], this.data[this.put_number]);
                        });

                        this.put_number++;
                        this.full++;
                        this.empty--;
                        GlobalVariables.buffer1_state = 0;
                        Thread.Sleep(1500);
                    }
                    else
                    {
                        Thread.Sleep(100);
                    }
                }
            });
        }

        public void Move(DataGridView dataGridView2, DataGridView dataGridView1)
        {
            Task.Run(() =>
            {
                while (true)
                {
                    if (GlobalVariables.buffer1_state == 0 && GlobalVariables.buffer2_state == 0 && this.full > 0)
                    {
                        GlobalVariables.buffer1_state = 1;
                        GlobalVariables.buffer2_state = 1;

                        this.buffer2.data[this.buffer2.move_number] = this.data[this.move_number];

                        dataGridView2.Invoke((MethodInvoker)delegate
                        {
                            dataGridView2.Rows.Add(this.order_number[this.move_number], this.buffer2.data[this.buffer2.move_number]);
                        });

                        this.buffer2.move_number++;
                        this.move_number++;
                        this.full--;
                        this.empty++;
                        this.buffer2.full++;
                        this.buffer2.empty--;

                        Thread.Sleep(2000);
                        GlobalVariables.buffer2_state = 0;
                        Thread.Sleep(200);
                        GlobalVariables.buffer1_state = 0;
                    }
                    else
                    {
                        Thread.Sleep(200);
                    }
                }
            });
        }

        public void Move1(DataGridView dataGridView5, DataGridView dataGridView1)
        {
            Task.Run(() =>
            {
                while (true)
                {
                    if (GlobalVariables.buffer1_state == 0 && GlobalVariables.buffer3_state == 0 && this.full > 0)
                    {
                        GlobalVariables.buffer1_state = 1;
                        GlobalVariables.buffer3_state = 1;

                        this.buffer3.data[this.buffer3.move_number] = this.data[this.move_number];

                        dataGridView5.Invoke((MethodInvoker)delegate
                        {
                            dataGridView5.Rows.Add(this.order_number[this.move_number], this.buffer3.data[this.buffer3.move_number]);
                        });

                        this.buffer3.move_number++;
                        this.move_number++;
                        this.full--;
                        this.empty++;
                        this.buffer3.full++;
                        this.buffer3.empty--;

                        Thread.Sleep(2000);
                        GlobalVariables.buffer3_state = 0;
                        Thread.Sleep(200);
                        GlobalVariables.buffer1_state = 0;
                    }
                    else
                    {
                        Thread.Sleep(200);
                    }
                }
            });
        }

        public void MarkAsFull()
        {
            Console.WriteLine("Buffer is full.");
        }

        public void MarkAsEmpty()
        {
            Console.WriteLine("Buffer is empty.");
        }

        public char RandomLow()
        {
            return (char)random.Next(97, 123);
        }
    }
}
