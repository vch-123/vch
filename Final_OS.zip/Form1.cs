﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_OS
{
    public partial class Form1 : Form
    {
        private Buffer1 buffer1;
        private Stopwatch stopwatch;

        public Form1()
        {
            InitializeComponent();
            InitGridView();
            buffer1 = new Buffer1(100);
            stopwatch = new Stopwatch();

            GlobalVariables.buffer1_state = 0;
            GlobalVariables.buffer2_state = 0;
            GlobalVariables.buffer3_state = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (buffer1.produce_click == 1)
            {
                buffer1.produce_click = 0;
            }
            else
            {
                buffer1.produce_click = 1;
            }

            buffer1.ProduceAsync(dataGridView4);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            buffer1.Put(dataGridView1, dataGridView4);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            buffer1.Move(dataGridView2, dataGridView1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            buffer1.buffer2.Get(dataGridView2, dataGridView3);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            buffer1.Move1(dataGridView5, dataGridView1);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            buffer1.buffer3.Get(dataGridView5, dataGridView6);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (!stopwatch.IsRunning)
            {
                stopwatch.Start();
            }
            else
            {
                stopwatch.Stop();
                lblTimeElapsed.Text = $"{stopwatch.Elapsed.TotalSeconds} seconds.";
                stopwatch.Reset();
            }
        }

        private void InitGridView()
        {
            dataGridView1.ColumnCount = 2;
            dataGridView1.Columns[0].Name = "序号";
            dataGridView1.Columns[1].Name = "数据";

            dataGridView2.ColumnCount = 2;
            dataGridView2.Columns[0].Name = "序号";
            dataGridView2.Columns[1].Name = "数据";

            dataGridView3.ColumnCount = 2;
            dataGridView3.Columns[0].Name = "序号";
            dataGridView3.Columns[1].Name = "数据";

            dataGridView4.ColumnCount = 2;
            dataGridView4.Columns[0].Name = "序号";
            dataGridView4.Columns[1].Name = "数据";

            dataGridView5.ColumnCount = 2;
            dataGridView5.Columns[0].Name = "序号";
            dataGridView5.Columns[1].Name = "数据";

            dataGridView6.ColumnCount = 2;
            dataGridView6.Columns[0].Name = "序号";
            dataGridView6.Columns[1].Name = "数据";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
