﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_OS
{
    class Buffer3
    {
        public int arrayroom;
        public int empty;
        public int full;

        public char[] data;
        public char[] car;
        public int car_empty;
        public int car_full;
        public int get_click = 0;
        public int get_number = 0;
        public int move_number = 0;

        public Buffer3(int capacity)
        {
            this.arrayroom = capacity;
            this.data = new char[capacity];
            this.car = new char[capacity];
            this.car_empty = capacity;
            this.car_full = 0;
            this.empty = capacity;
            this.full = 0;
        }

        public void Get(DataGridView dataGridView5, DataGridView dataGridView6)
        {
            Task.Run(() =>
            {
                while (true)
                {
                    if (this.full > 0 && GlobalVariables.buffer3_state == 0)
                    {
                        GlobalVariables.buffer3_state = 1;
                        this.car[this.get_number] = this.data[this.get_number];
                        this.full--;
                        this.empty++;
                        this.car_empty--;
                        this.car_full++;
                        dataGridView6.Invoke((MethodInvoker)delegate
                        {
                            dataGridView6.Rows.Add(dataGridView5.Rows[this.get_number].Cells[0].Value, this.car[this.get_number]);
                        });
                        this.get_number++;
                        Thread.Sleep(2000);
                        GlobalVariables.buffer3_state = 0;
                    }
                    else
                    {
                        Thread.Sleep(100);
                    }
                }
            });
        }
    }
}
